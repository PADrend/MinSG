/* basic/test-hello.c --- Minimal test of Basic C (mainly 4 portability) */

/* cc -I../inculde -L../lib <THIS_FILE> -l_basic -lm [-lmalloc] */
/*                                                   ^ on SGI ^ */

#include "basic.h"
extern const char basic__version[];

//static void print_system (void);
//
//void main (int argc, char *argv[])
//{
//  char *p;
//  print_system ();
//  print ("%s\n", basic_cb_frmt ("Say %s?", "WHAT"));
//  p = basic_cb_getline (stdin);
//  if (p)
//    {
//      print ("Ah! You typed %d chars: %s", (int) strlen (p), p);
//    }
//  else
//    {
//      print ("EOF\n");
//    }
//}
//
//void print_system (void)
//{
//  char *p, *a;
//  ;
//#if defined (sgi)
//  p = STRDUP ("SGI");
//#elif defined (sparc)
//  p = STRDUP ("SPARC");
//#elif defined (sun)
//  p = STRDUP ("SUN, non-SPARC");
//#elif defined (NeXT)
//  p = STRDUP ("NeXT");
//#else
//  p = STRDUP ("Unknown");
//#endif
//  ;
//  p = STRDUP (basic_cb_frmt ("This is %s on %s%s",
//                             basic_strip (basic__version), p, a));
//  print ("HELLO WORLD!\n%s, %s\n",
//         p, basic_cb_frmt ("%s on %s", basic_date (), basic_hostname ()));
//}
