/* rx/files.c - Encapsulated file utilities. */

/*--------------------------------------------------------------------------*/

/* rx_fopen (pathname, "r") will first look for a compressed file, that is:
   "pathname.<Z>", where ".<Z>" stands for any supported compression extension,
   uncompress it (via a Unix pipe) and open it for reading (from the pipe).
   Is the mode == "w", rx_fopen() will delete the compressed file, and create
   a new (uncompressed) file pathname.
   
   Different compression schemes for different files are possible!
   The pathname can also contain the compression extension!
   */

/*--------------------------------------------------------------------------*/

/* Interface: see rx.h */

#include "rx.h"

/*--------------------------------------------------------------------------*/

#define __IMPLEMENTATION__

/*--------------------------------------------------------------------------*/

#if defined(__MWERKS__) || defined(macintosh) 
# define _AUTO_DECOMP 0
#else
# define _AUTO_DECOMP 1
#endif

#if (_AUTO_DECOMP == 1)

/* The "auto decompression" feature makes heavy use of pipes.  Unix has
   popen() and pclose() for this, and we also need fileno().  These functions
   are not in ANSI C.  If a platform doesn't have them, turn this off. */

/* Since this is not ANSI C, #include <stdio.h> might not have the prototypes,
   even though the fuctions apparently still exist on most systems... */

FILE *popen (const char *command, const char *type);
int pclose (FILE *file);

#if !defined (fileno)
 int fileno (FILE *stream);
# endif

#else /* for (_AUTO_DECOMP == 0) */

/* The "auto decompression" feature is turned off; probably because the
   platform does not have popen()/pclose().  In this case, select_scheme()
   will act "stupid" and never return non-0, and and popen(), pclose(), and
   fileno() are dummies. */

static FILE *popen (const char *command, const char *type) { return (NULL); }
static int pclose (FILE *file) { return (-1); }
static int fileno (FILE *stream) { return (-1); }

#endif

/*--------------------------------------------------------------------------*/

/* In Unix, access() can be used to check file access rights. This turns out
   to be non-ANSI C as well, and we need to furhter encapsulate this since
   some systems don't have it. */

static int read_access (const char* path);
static int write_access (const char* path);

#if defined(__MWERKS__) || defined(macintosh)

/* ... if access() doesn't exist, simply simulate with fopen() ... */

static int read_access (const char* path)
{
  FILE *buf = fopen (path, "r");
  int result = (buf != NULL);
  fclose (buf);
  return (result);
}

static int write_access (const char* path)
{
  FILE *buf = fopen (path, "w");
  int result = (buf != NULL);
  fclose (buf);
  return (result);
}

#else

/* ... otherwise (e.g., under Unix), just #include <unistd.h> and use it ... */

#if defined(__irix64)
/* On SGI IRIX64 under ANSI C,
   #include <unistd.h> produces a funny warning...
   This hack should shut up this up. */
 pid_t __vfork(void);
#endif

#include <unistd.h>

#if defined(__irix64)
 void basic_dummy_never_never_called (void) { vfork (); }
#endif

static int read_access (const char* path)
{
  return (access (path, F_OK) != -1);
}

static int write_access (const char* path)
{
  return (access (path, W_OK) != -1);
}

#endif

/*--------------------------------------------------------------------------*/

/* Unix has also stat() to get the file status.  This is used here to get
   the access and modification times.  Again, this is not ANSI C.  If a
   platform doesn't have this at all, we'll need to rewrite this.... (???) */

#if defined(__MWERKS__) || defined(macintosh)
# include <stat.h>
#else
# include <sys/stat.h>
#endif

/*--------------------------------------------------------------------------*/

typedef struct plist_record
{
  int id;
  struct plist_record *next;
  char *fname;
  char *zname;
} Plist;
static Plist *plist = NULL;  /* linked list remembering popen()s */
static Plist *flist = NULL;  /* linked list remembering popen()s;
                                NOTE: both lists are never de-allocated! */

static const char *frmt[] = { "",    "%s.gz",      "%s.z",         "%s.Z", 0 };
static const char  *ext[] = { "",      ".gz",        ".z",           ".Z", 0 };
static const char  *cmd[] = { "", "gzip -dc", "gunzip -c", "compress -dc", 0 };

static Plist *push (Plist *p, FILE *file,
                    const char fname[], const char zname[]);
static void forget (Plist *p);
static int select_scheme (char fname[]);

/*--------------------------------------------------------------------------*/

FILE *rx_fopen (const char path_name[], const char mode[])
     /* Opens file with given path_name in given mode. Cf, man fopen. */
{
  FILE *file;
  char fname[MAXPATHLEN];
  char fmode[20];
  sprint (fname, "%s", path_name);
  sprint (fmode, "%s", mode);
  { /* check for compressed file first */
    static char zname[MAXPATHLEN];
    int scheme = select_scheme (fname);
    sprint (zname, frmt[scheme], fname);
    if ((scheme != 0) && read_access (zname))
      { /* zname == "" */
        if (strpbrk (fmode, "wW"))
          {
            if (! write_access (zname))
              rx_error ("rx_fopen: Can't remove file \"%s\".", zname);
            print ("[Removing compressed file \"%s\" ...]\n", zname);
            rx_system ("rm -f %s", zname);
            file = fopen (fname, fmode);
            if (file)
              flist = push (flist, file, fname, NULL);
          }
        else
          { /* open compressed file for reading using popen() */
            char buffer[20+MAXPATHLEN];
            sprintf (buffer, "%s %s", cmd[scheme], zname);
            file = popen (buffer, "r");
            if (file)
              plist = push (plist, file, fname, zname);
          }
      }
    else
      {
        file = fopen (fname, fmode);
        if (file)
          flist = push (flist, file, fname, NULL);
      }
    if (! file)
      rx_error ("rx_fopen: Can't open file \"%s\", %s \"%s\".",
                fname, "with mode", fmode);
  }
  return (file);
}

/*--------------------------------------------------------------------------*/

void rx_fclose (FILE *file)
     /* Closes the given file.  Cf, man fclose. */
{
  Plist *p = plist;
  while (p != NULL)
    { /* if file is in plist, use pclose() */
      if (p->id == fileno (file))
        { 
          if (pclose (file) != 0)
            fprint (stderr, "\nWARNING: rx_fclose: UNSUCCESSFUL pclose()\n\n");
          forget (p);
          return;
        }
      p = p->next;
    }
  /* otherwise, use fclose() */
  if (fclose (file) != 0)
    fprint (stderr, "\nWARNING: rx_fclose: UNSUCCESSFUL fclose()\n\n");
}

/*--------------------------------------------------------------------------*/
 
static Plist *push (Plist *p, FILE *file,
                    const char fname[], const char zname[])
    /* push file id onto p; use malloc() to "hide" it; NO de-allocation! */
{
  Plist *new = (Plist *) malloc (sizeof (Plist));
  new->id = fileno (file);
  new->next = p;
  new->fname = STRDUP (fname);
  if (zname)
    new->zname = STRDUP (zname);
  else
    new->zname = new->fname;
  return (new);
}

static void forget (Plist *p)
     /* Forget Plist entry; but NO de-allocation! */
{
  p->id = 0;
  /* ... but, yes, we de-allocate the paths */
  if (p->fname == p->zname)
    free (p->fname);
  else
    {
      free (p->fname);
      free (p->zname);
    }
  p->fname = p->zname = NULL;
}

/*--------------------------------------------------------------------------*/

static int select_scheme (char fname[])
     /* NOTE: select_scheme MIGHT change fname[]! */
{
#if (_AUTO_DECOMP == 0)
  return (0);
#else
  char zname[MAXPATHLEN];
  int scheme = 0, i = 1;
  size_t len = strlen (fname);
  while (ext[i])
    { /* test for fname[] already having extension ext[i] */
      size_t xlen = strlen (ext[i]);
      if ((len >= xlen) && (strcmp (&(fname[len - xlen]), ext[i]) == 0))
        { /* remove extension */
          fname[len - xlen] = '\0';
        }
      i ++;
    }
  i = 1;
  while (frmt[i])
    { /* look for compressed version of fname[] */
      sprint (zname, frmt[i], fname);
      if (read_access (zname))
        {
          if (scheme == 0)
            {
              scheme = i;
#if 0
              print ("[Using '%s %s' to decompress file \"%s\"]\n",
                     cmd[i], frmt[i], zname);
#endif
              return (scheme);
            }
          else
            {
              char zname1[MAXPATHLEN];
              sprint (zname1, frmt[scheme], fname);
              fprint (stderr, "\nWARNING: %s\n   %s %s\n   %s %s\n   %s\n\n",
                      "COMPRESSION SCHEME CONFLICT!", "     FOUND", zname1,
                      "AS WELL AS", zname, "THE LATTER IS IGNORED!");
            }
        }
      i ++;
    }
  return (scheme);
#endif
}

/*--------------------------------------------------------------------------*/

int rx_access (const char path_name[])
     /* Checks if file with given path_name exists. Cf, man access. */
{
  char fname[MAXPATHLEN];
  sprint (fname, "%s", path_name);
  if (read_access (fname))
    return (TRUE);
  else
    { /* check for fname.<Z> */
      char zname[MAXPATHLEN];
      int scheme = select_scheme (fname);
      sprint (zname, frmt[scheme], fname);
      return (read_access (zname));
    }
}

/*--------------------------------------------------------------------------*/

time_t rx_modtime (const char path_name[])
     /* Returns last modifaction time of file, measured in (time_t) seconds
        since 00:00:00, Jan 1, 1970.  NOTE: Figuring out whether the file
        is compressed or not is a hack! */
{
  time_t no_access = (time_t) 0;
  if (! rx_access (path_name))
    return (no_access);
  else
    {
      struct stat buf;
      if (stat (path_name, &buf) == 0)
        return (buf.st_mtime);
      else
        { /* check for compressed file; spaghetti code... */
          char zname[MAXPATHLEN];
          char fname[MAXPATHLEN];
          int scheme;
          sprint (fname, "%s", path_name);
          scheme = select_scheme (fname);
          sprint (zname, frmt[scheme], fname);
          if (stat (zname, &buf) == 0)
            return (buf.st_mtime);
          else
            return (no_access);
        }
    }
}

/*--------------------------------------------------------------------------*/

void rx_rm (const char path_name[])
     /* Removes file with given path_name[]. */
     /* NOTE: What about compression scheme!?!? */
{
  /* Note: shouldn't we test for existence or whether it's a directory? */
  if (remove (path_name) != 0)
    fprint (stderr, "WARNIG: rx_rm (\"%s\") failed!\n", path_name);
}

/*--------------------------------------------------------------------------*/

static const char *fb_name (FILE *file, int b)
    /* local refinement to rx_fname() and rx_bname() below */
{
  Plist *p = plist;
  while (p != NULL)
    {
      if (p->id == fileno (file))
        return (If (b, p->fname, p->zname));
      p = p->next;
    }
  
  p = flist;
  while (p != NULL)
    {
      if (p->id == fileno (file))
        return (p->fname);
      p = p->next;
    }
  return ("(Unknown)");
}

const char *rx_fname (FILE *file)
    /* Returns the path name with which the file was opened w/ rx_fopne() */
{
  return (fb_name (file, 0));
}

const char *rx_bname (FILE *file)
    /* Ditto, but strips off the compression extension, if any! */
{
  return (fb_name (file, 1));
}
