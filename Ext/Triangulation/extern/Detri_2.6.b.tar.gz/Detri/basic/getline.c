/* rx/getline.c --- Simple line-oriented parsing: getline & tokenize */

/*--------------------------------------------------------------------------*/

/* Imports */

#include <stdio.h>
#include <ctype.h>

/*--------------------------------------------------------------------------*/

/* Runtime error handling (change to fit application) */

/* abort_with() is called whenever a (nonrecoverable) runtime error
   is encountered.  Can be redefined, but it better aborts execution! */

#define abort_with(MSG)             rx_error (efrmt, __FILE__, __LINE__, MSG)

void rx_error (const char *frmt, ...);
static char efrmt[] = "\n\n  RUNTIME ERROR, %s: %d\n  MESSAGE: %s\n\n";

/*--------------------------------------------------------------------------*/

/* Human-readable logical operators */

/*
#define and    &&
#define or     ||
#define not    !
#define mod    %
*/

/*--------------------------------------------------------------------------*/

int rx_getline (FILE *file, char buffer[], int len)
     /* Reads characters from given file until '\n' or EOF is reached and
        puts them to the buffer[0..len-1].  Any character for which isspace()
        is true is replaced by ' ' and the '\n' is replaced by '\0'
        ... This means that the resulting string will be "\0\0"-terminated!
        It returns the number of chars read from the file,
        which is 0 if the file is at EOF. */
{
  int c, i = 0;
  for (;;)
    {
      c = getc (file);
      if (c == EOF)
        break;
      else
        {
          i ++;
          if (i == len - 2)
            abort_with ("getline() overflow");
          if (c == '\n')
            {
              buffer[i - 1] = '\0';
              break;
            }   
          else if (isspace (c))
            buffer[i - 1] = ' ';
          else
            buffer[i - 1] = c;
        }
    }
  buffer[i] = '\0';
  return (i);
}

/*--------------------------------------------------------------------------*/

static void shift_left (char string[])
     /* Input/Output: string[]. */
     /* Shifts non-empty string[0..] to string[1..] */
{
  int i = 0;
  while (string[i])
    {
      string[i] = string[i+1];
      i ++;
    }
}

/*--------------------------------------------------------------------------*/

int rx_tokenize (char string[], char *token[], int maximum)
     /* Input/Output: string[]
        NOTE: string[] will be destroyed! */
     /* Output: token[0..maximum-1]. */
     /* This routine parses the given string and breaks it up into different
        tokens.  Tokens are delimited by blanks -- or any special character
        for which isspace() returns non-zero.
        The function returns the number of tokens parsed or -1 when it
        would have exceeded the maximum.
        NOTE:
        . Use quotes ("balh blah") when a token is to contain blanks.
        . Use \" for the quote character and \\ for the backslash.
        */
{
  int j = 0, i = 0;
  while (string[i])
    {
      while (isspace (string[i]))
        i ++;
      if (string[i])
        {
          if (j == maximum)
            return (-1);
          token[j++] = &(string[i]);  
          while (string[i] && (! isspace (string[i])))
            { /* parse token */
              if ((string[i] == '\\') && (string[i+1] == '"'))
                shift_left (&(string[i]));  /* quote as a character */
              else if (string[i] == '"')
                { /* parse quoted token */
                  shift_left (&(string[i]));
                  while (string[i])
                    {
                      if ((string[i] == '\\') && (string[i+1] == '"'))
                        { /* quote as a character within quoted string */
                          shift_left (&(string[i]));
                          i ++;
                        }
                      else if (string[i] == '"')
                        string[i] = 0;
                      else
                        i ++;
                    }
                }
              i ++;
            }
          if (string[i])
            {
              string[i] = 0;
              i ++;
            }
        }
    }
  return (j);
}
