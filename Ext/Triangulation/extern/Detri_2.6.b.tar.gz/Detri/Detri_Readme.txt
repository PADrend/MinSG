2011-09-05
This code is a slightly modified version of the Detri[1] from Ernst M�cke library. There have been made no algorithmic changes; only the interface has been adapted. The original sourcecode can be aquired from the given source.

[1] Ernst M�cke, Robust 3D Delaunay triangulations, http://www.geom.uiuc.edu/~mucke/GeomDir/detri.html, 1998.